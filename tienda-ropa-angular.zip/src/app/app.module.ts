import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from "@angular/router";
import { AngularFireModule } from 'angularfire2';
import { AngularFireDatabaseModule } from 'angularfire2/database';


import { AppComponent } from './app.component';
import { ProductosComponent } from './productos/productos.component';
import { ContactoComponent } from './contacto/contacto.component';
import { HomeComponent } from './home/home.component';
import { environment } from '../environments/environment';
import { PieComponent } from './pie/pie.component';
import { CabeceraComponent } from './cabecera/cabecera.component';
import { MenuComponent } from './menu/menu.component';
import { LoginComponent } from './login/login.component';

const routes: Routes = [
  {
    path: "",
    component: HomeComponent
  },
  {
    path: "home",
    component: HomeComponent
  },
  {
    path: "productos",
    component: ProductosComponent
  },
  {
    path: "contacto",
    component: ContactoComponent
  },
  {
    path: "login",
    component: LoginComponent
  }
];

export const firebaseConfig = {
  apiKey: "AIzaSyDlVdM1PhgPd3I2Q5hi03YVzgcc7a6ax1Q",
  authDomain: "tienda-ropa-angular.firebaseapp.com",
  databaseURL: "https://tienda-ropa-angular.firebaseio.com",
  projectId: "tienda-ropa-angular",
  storageBucket: "tienda-ropa-angular.appspot.com",
  messagingSenderId: "218379673057"
};

@NgModule({
  declarations: [
    AppComponent,
    ProductosComponent,
    ContactoComponent,
    HomeComponent,
    PieComponent,
    CabeceraComponent,
    MenuComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(routes),
    AngularFireModule.initializeApp(firebaseConfig),
    AngularFireDatabaseModule,
  ],
  providers: [],
  bootstrap: [AppComponent],
  exports: [RouterModule]
})

export class AppModule { }
