import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from "@angular/router";
import {AngularFireModule} from 'angularfire2';


import { AppComponent } from './app.component';
import { ProductosComponent } from './productos/productos.component';
import { ContactoComponent } from './contacto/contacto.component';
import { HomeComponent } from './home/home.component';

const routes: Routes = [
  {
    path: "",
    component: HomeComponent
  },
  {
    path: "home",
    component: HomeComponent
  },
  {
    path: "productos",
    component: ProductosComponent
  },
  {
    path: "contacto",
    component: ContactoComponent
  }
];

export const firebaseConfig = {
  apiKey: "AIzaSyDqIShE1lO-NJ1aU9hDIeAAwlUbV8KeTyY",
    authDomain: "angular5-httpclient.firebaseapp.com",
    databaseURL: "https://angular5-httpclient.firebaseio.com",
    projectId: "angular5-httpclient",
    storageBucket: "angular5-httpclient.appspot.com",
    messagingSenderId: "726050088151"
};

@NgModule({
  declarations: [
    AppComponent,
    ProductosComponent,
    ContactoComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(routes),
    AngularFireModule.initializeApp(firebaseConfig)
  ],
  providers: [],
  bootstrap: [AppComponent],
  exports: [RouterModule]
})

export class AppModule { }
