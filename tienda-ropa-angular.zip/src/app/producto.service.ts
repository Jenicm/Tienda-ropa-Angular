import { Injectable } from '@angular/core';
import { AngularFireDatabase } from 'angularfire2/database';
import { Producto } from './model/producto.model';


@Injectable()
export class ProductoService {

    private productoListRef = this.db.list<Producto>('productos');

    constructor(private db: AngularFireDatabase) { }

    // getProductoList() {
    //     return this.productoListRef;
    // }

    // addProducto(producto: Producto) {
    //     return this.productoListRef.push(producto);
    // }

    // updateProducto(producto: Producto) {
    //     return this.productoListRef.update(producto.id, producto);
    // }

    // removeProducto(producto: Producto) {
    //     return this.productoListRef.remove(producto.id);
    // }
}