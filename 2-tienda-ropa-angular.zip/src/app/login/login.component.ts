import { Component, OnInit } from '@angular/core';
import { HttpClient } from 'selenium-webdriver/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  // email:any;
  // password:any;

  // constructor(private http: HttpClient, private router: Router,  private authService: AuthService) { 
  //    }

  // ngOnInit() {
  // }
  
  // login(){
  //   this.authService.login(this.email, this.password);
  // }

  // onClickLogout() {
  //   this.authService.logout();
  // }
}
