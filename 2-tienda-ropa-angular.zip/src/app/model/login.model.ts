export interface Login {
    id: string;
    nombre: string;
    email: string;
    pass: string;
}