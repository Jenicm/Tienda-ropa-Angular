import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { AngularFireDatabase } from 'angularfire2/database';

@Component({
  selector: 'app-productos',
  templateUrl: './productos.component.html',
  styleUrls: ['./productos.component.css']
})
export class ProductosComponent implements OnInit {

  ProductosObservable: Observable<any[]>;
  
  constructor(private db: AngularFireDatabase) { }

  ngOnInit() {
    this.ProductosObservable = this.getProductos('/Productos');
  }
  
  getProductos(listPath): Observable<any[]> {
    return this.db.list(listPath).valueChanges();
  }
}

