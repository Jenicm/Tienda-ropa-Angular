import {Injectable} from '@angular/core';
import {AngularFireDatabase, AngularFireList} from 'angularfire2/database';
import { Contacto } from '../model/contacto.modelo';


@Injectable()
export class ContactoService { 
 
  contactosRef: AngularFireList<Contacto> = null;
 
  constructor(private db: AngularFireDatabase) {
    this.contactosRef = db.list('/Contactos');
  }
 
  addContacto(contacto: Contacto): void {
    this.contactosRef.push(contacto);
  }
 
  getContactosList(): AngularFireList<Contacto> {
    return this.contactosRef;
  }
 
  private handleError(error) {
    console.log(error);
  }
}

