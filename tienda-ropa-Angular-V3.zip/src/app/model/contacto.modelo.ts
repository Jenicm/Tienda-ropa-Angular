export class Contacto {
    id: string;
    nombre: string;
    mail: string;
    telefono: string;
    comentario: string;
  }