import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from "@angular/router";
import { AngularFireModule } from 'angularfire2';
import { AngularFireDatabaseModule } from 'angularfire2/database';


import { AppComponent } from './app.component';
import { ProductosComponent } from './productos/productos.component';
import { CookieService } from 'ngx-cookie-service';
import { HomeComponent } from './home/home.component';
import { environment } from '../environments/environment';
import { PieComponent } from './pie/pie.component';
import { CabeceraComponent } from './cabecera/cabecera.component';
import { MenuComponent } from './menu/menu.component';
import { DetallesProductoComponent } from './detalles-producto/detalles-producto.component';
import { LoginComponent } from './login/login.component';
import { CarritoComponent } from './carrito/carrito.component';
import { ContactoService } from './service/contacto.service';
import { ProductoService } from './service/producto.service';
//import { ContactoComponent } from './contacto/contacto.component';
import { ErrorComponent } from './error/error.component';

const routes: Routes = [
  {
    path: "",
    component: HomeComponent
  },
  {
    path: "home",
    component: HomeComponent
  },
  {
    path: "productos",
    component: ProductosComponent
  },
  // {
  //   path: "contacto",
  //   component: ContactoComponent
  // },
  {
    path: "detallesProducto/:id",
    component: DetallesProductoComponent
  },
  {
    path: "carrito",
    component: CarritoComponent
  },
  {
    path: "**",
    component: ErrorComponent
  }
];

export const firebaseConfig = {
  apiKey: "AIzaSyDlVdM1PhgPd3I2Q5hi03YVzgcc7a6ax1Q",
  authDomain: "tienda-ropa-angular.firebaseapp.com",
  databaseURL: "https://tienda-ropa-angular.firebaseio.com",
  projectId: "tienda-ropa-angular",
  storageBucket: "tienda-ropa-angular.appspot.com",
  messagingSenderId: "218379673057"
};

@NgModule({
  declarations: [
    AppComponent,
    ProductosComponent,
    //ContactoComponent,
    HomeComponent,
    PieComponent,
    CabeceraComponent,
    MenuComponent,
    DetallesProductoComponent,
    LoginComponent,
    CarritoComponent,
    ErrorComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(routes),
    AngularFireModule.initializeApp(firebaseConfig),
    AngularFireDatabaseModule
  ],
  providers: [
    CookieService,
    ContactoService,
    ProductoService
  ],
  bootstrap: [AppComponent],
  exports: [RouterModule]
})

export class AppModule { }
