import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from 'selenium-webdriver/http';
import { Contacto } from '../model/contacto.modelo';
import { ContactoService } from '../service/contacto.service';

@Component({
  selector: 'app-contacto',
  templateUrl: './contacto.component.html',
  styleUrls: ['./contacto.component.css']
})
export class ContactoComponent implements OnInit {

  contacto: Contacto = new Contacto();
  submitted = false;
  
  constructor(private contactoService: ContactoService, private http: HttpClient, private router: Router) { }

  ngOnInit() {
  }

  newContacto(): void {
    this.submitted = false;
    this.contacto = new Contacto();
  }
 
  saveContacto() {
    this.contactoService.addContacto(this.contacto);
    this.contacto = new Contacto();
  }
 
  onSubmit() {
    this.submitted = true;
    this.saveContacto();
  }
}
