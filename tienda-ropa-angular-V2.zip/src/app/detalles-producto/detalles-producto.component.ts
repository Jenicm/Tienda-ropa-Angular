import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { AngularFireDatabase } from 'angularfire2/database';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-detalles-producto',
  templateUrl: './detalles-producto.component.html',
  styleUrls: ['./detalles-producto.component.css']
})
export class DetallesProductoComponent implements OnInit {

  ProductosObservable: Observable<any[]>;
  id: number;

  constructor(private db: AngularFireDatabase, private route: ActivatedRoute) { }

  ngOnInit() {
    this.id = this.route.snapshot.params["id"];
    this.ProductosObservable = this.getProductos('/Productos');
  }
  
  getProductos(listPath): Observable<any[]> {
    return this.db.list(listPath).valueChanges();
  }

}
