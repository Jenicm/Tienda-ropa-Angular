export interface Producto {
    id: string;
    nombre: string;
    descripcion: string;
    precio: string;
    imagen: string;
}