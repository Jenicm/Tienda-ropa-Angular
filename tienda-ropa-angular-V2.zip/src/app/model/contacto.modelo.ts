export class Contacto {
    _id: string;
    nombre: string;
    mail: string;
    telefono: string;
    comentario: string;
  }